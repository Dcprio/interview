package com.msb;

import com.msb.entity.OrderTest;
import com.msb.entity.UserTest;
import com.msb.util.NameUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.*;

/**
 * @Author:
 * @Date: 2018/11/9 17:31
 * @Description:
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@EnableAutoConfiguration
public class OrderInnoDBBatchInsertTest {

    @Autowired
    JdbcTemplate jdbcTemplate;

    List<OrderTest> list;

    private static final int USER_COUNT = 500000; // 数量过大可能导致内存溢出，多运行几次


    @Test
    public void testInsert() {
        long start = System.currentTimeMillis();
        list = new ArrayList<>();
        for (int i=1; i< USER_COUNT+1; i++){
            OrderTest order = new OrderTest();
            order.setId(i);
            order.setOrderTime(new Date());
            order.setAmount(new BigDecimal(1.1));
            order.setProductId(new Random().nextInt(12000));
            order.setStatus(new Random().nextInt(2));
            order.setUserId(new Random().nextInt(500000));

            list.add(order);
        }

        save(list);
        long end = System.currentTimeMillis();
        System.out.println("批量插入"+USER_COUNT+"条用户数据完毕，总耗时：" + (end - start) + " 毫秒");

    }

    /**
     * 必须要在数据库连接url加上 &rewriteBatchedStatements=true 来开启批处理，否则还是一条一条写入的
     * 检查IP地址
     * @param list
     */
    public void save(List<OrderTest> list) {
        final List<OrderTest> tempList = list;

        String sql = "insert into orders(id, user_id, order_time, amount,status,product_id) "
                + "values(?, ?, ?, ?, ?, ?)";
        jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
            public void setValues(PreparedStatement ps, int i) throws SQLException {

                Integer id = tempList.get(i).getId();
                Integer userId = tempList.get(i).getUserId();
                Integer productId = tempList.get(i).getProductId();
                Date orderTime = tempList.get(i).getOrderTime();
                Integer status = tempList.get(i).getStatus();
                BigDecimal amount = tempList.get(i).getAmount();

                ps.setInt(1, id);
                ps.setInt(2, userId);
                ps.setDate(3, new java.sql.Date(System.currentTimeMillis()));
                ps.setBigDecimal(4, amount);
                ps.setInt(5, status);
                ps.setInt(6, productId);
            }

            public int getBatchSize() {
                return tempList.size();
            }
        });

    }

    public static int getNum(int start,int end) {
        return (int)(Math.random()*(end-start+1)+start);
    }

    private static String[] telFirst="181,185,136,137,138,179,150,151,152,157,158,159,130,131,132,155,156,199,153,189,166".split(",");
    private static String getTel() {
        int index=getNum(0,telFirst.length-1);
        String first=telFirst[index];
        String second=String.valueOf(getNum(1,888)+10000).substring(1);
        String third=String.valueOf(getNum(1,9100)+10000).substring(1);
        return first+second+third;
    }

}
