package com.msb.entity;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class OrderTest {


    private Integer id; // ID，数据库自增
    private Integer userId;
    private Date orderTime; //
    private BigDecimal amount; //
    private Integer status  ; //
    private Integer productId   ; //
}
